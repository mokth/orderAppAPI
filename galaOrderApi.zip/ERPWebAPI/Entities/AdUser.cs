﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace galaCoreAPI.Entities
{
    //[Table("AdUser")]
    //public class AdUser
    //{
    //    [Key]
    //    public string id { get; set; }
    //    public string name { get; set; }
    //    public string pWord { get; set; }
    //    public bool? active { get; set; }
    //    public string role { get; set; }
    //    public string country { get; set; }
    //    public string state { get; set; }
    //    public string city { get; set; }
    //    public string area { get; set; }
    //    public string location { get; set; }
    //    public string company { get; set; }
    //    public string branch { get; set; }
    //    public bool? chgpass { get; set; }
    //}
}
